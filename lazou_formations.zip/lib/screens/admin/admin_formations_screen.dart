import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../models/formation.dart';
import '../../services/firestore_service.dart';
import '../../theme/app_theme.dart';

class AdminFormationsScreen extends StatelessWidget {
  const AdminFormationsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final firestore = context.read<FirestoreService>();

    return Scaffold(
      appBar: AppBar(title: const Text('Formations')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => _ouvrirFormulaireAjout(context, firestore),
        icon: const Icon(Icons.add),
        label: const Text('Ajouter'),
      ),
      body: StreamBuilder<List<Formation>>(
        stream: firestore.watchFormations(),
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          final formations = snapshot.data ?? [];
          if (formations.isEmpty) {
            return const Center(
              child: Padding(
                padding: EdgeInsets.all(24),
                child: Text(
                  'Aucune formation ajoutée pour l\'instant.\nAppuie sur "Ajouter" pour créer la première.',
                  textAlign: TextAlign.center,
                ),
              ),
            );
          }
          return ListView.separated(
            padding: const EdgeInsets.fromLTRB(16, 16, 16, 88),
            itemCount: formations.length,
            separatorBuilder: (_, __) => const SizedBox(height: 10),
            itemBuilder: (context, i) {
              final f = formations[i];
              return Card(
                child: ListTile(
                  title: Text(f.titre, style: const TextStyle(fontWeight: FontWeight.w700)),
                  subtitle: Text('${f.domaine.label} · ${f.duree}'),
                  trailing: IconButton(
                    icon: const Icon(Icons.delete_outline, color: LazouColors.error),
                    onPressed: () => firestore.supprimerFormation(f.id),
                  ),
                ),
              );
            },
          );
        },
      ),
    );
  }

  void _ouvrirFormulaireAjout(BuildContext context, FirestoreService firestore) {
    final titreCtrl = TextEditingController();
    final descCtrl = TextEditingController();
    final dureeCtrl = TextEditingController();
    FormationDomaine domaine = FormationDomaine.informatique;
    final formKey = GlobalKey<FormState>();

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (ctx) => Padding(
        padding: EdgeInsets.only(
          left: 20,
          right: 20,
          top: 20,
          bottom: MediaQuery.of(ctx).viewInsets.bottom + 20,
        ),
        child: StatefulBuilder(
          builder: (ctx, setState) => Form(
            key: formKey,
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  const Text('Nouvelle formation', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 17)),
                  const SizedBox(height: 16),
                  TextFormField(
                    controller: titreCtrl,
                    decoration: const InputDecoration(labelText: 'Titre'),
                    validator: (v) => (v == null || v.trim().isEmpty) ? 'Champ requis' : null,
                  ),
                  const SizedBox(height: 12),
                  DropdownButtonFormField<FormationDomaine>(
                    initialValue: domaine,
                    decoration: const InputDecoration(labelText: 'Domaine'),
                    items: FormationDomaine.values
                        .map((d) => DropdownMenuItem(value: d, child: Text(d.label)))
                        .toList(),
                    onChanged: (v) => setState(() => domaine = v ?? domaine),
                  ),
                  const SizedBox(height: 12),
                  TextFormField(
                    controller: dureeCtrl,
                    decoration: const InputDecoration(labelText: 'Durée (ex: 2 mois)'),
                    validator: (v) => (v == null || v.trim().isEmpty) ? 'Champ requis' : null,
                  ),
                  const SizedBox(height: 12),
                  TextFormField(
                    controller: descCtrl,
                    decoration: const InputDecoration(labelText: 'Description'),
                    maxLines: 3,
                  ),
                  const SizedBox(height: 20),
                  ElevatedButton(
                    onPressed: () {
                      if (!formKey.currentState!.validate()) return;
                      final id = titreCtrl.text.trim().toLowerCase().replaceAll(RegExp(r'\s+'), '-');
                      firestore.ajouterFormation(
                        Formation(
                          id: id,
                          titre: titreCtrl.text.trim(),
                          domaine: domaine,
                          description: descCtrl.text.trim(),
                          duree: dureeCtrl.text.trim(),
                          modules: const [],
                        ),
                      );
                      Navigator.of(ctx).pop();
                    },
                    child: const Text('Créer la formation'),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
