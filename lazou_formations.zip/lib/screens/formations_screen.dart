import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../data/mock_formations.dart';
import '../models/formation.dart';
import '../services/firestore_service.dart';
import '../widgets/animations.dart';
import '../widgets/formation_card.dart';
import 'formation_detail_screen.dart';

class FormationsScreen extends StatelessWidget {
  const FormationsScreen({super.key});

  /// En mode connecté, FirestoreService est fourni par main.dart. En mode
  /// démo (Firebase pas configuré), il ne l'est pas — on retombe sur le
  /// mock plutôt que de planter.
  FirestoreService? _firestoreOuNull(BuildContext context) {
    try {
      return context.read<FirestoreService>();
    } catch (_) {
      return null;
    }
  }

  @override
  Widget build(BuildContext context) {
    final firestore = _firestoreOuNull(context);

    if (firestore == null) {
      return _FormationsListe(formations: mockFormations);
    }

    return StreamBuilder<List<Formation>>(
      stream: firestore.watchFormations(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return const Scaffold(body: Center(child: CircularProgressIndicator()));
        }
        // Catalogue Firestore vide (rien ajouté par l'admin pour l'instant)
        // -> on montre quand même le contenu de démo plutôt qu'un écran vide.
        final formations = (snapshot.data?.isNotEmpty ?? false) ? snapshot.data! : mockFormations;
        return _FormationsListe(formations: formations);
      },
    );
  }
}

class _FormationsListe extends StatefulWidget {
  final List<Formation> formations;
  const _FormationsListe({required this.formations});

  @override
  State<_FormationsListe> createState() => _FormationsListeState();
}

class _FormationsListeState extends State<_FormationsListe> {
  FormationDomaine? _filtre;

  @override
  Widget build(BuildContext context) {
    final liste = widget.formations
        .where((f) => _filtre == null || f.domaine == _filtre)
        .toList();

    return Scaffold(
      appBar: AppBar(title: const Text('Formations')),
      body: Column(
        children: [
          SizedBox(
            height: 48,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              children: [
                _FilterChip(label: 'Tout', selected: _filtre == null, onTap: () => setState(() => _filtre = null)),
                ...FormationDomaine.values.map(
                  (d) => _FilterChip(
                    label: d.label,
                    selected: _filtre == d,
                    onTap: () => setState(() => _filtre = d),
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            child: liste.isEmpty
                ? const Center(child: Text('Aucune formation dans cette catégorie'))
                : ListView.separated(
                    padding: const EdgeInsets.all(16),
                    itemCount: liste.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 12),
                    itemBuilder: (context, i) => FadeSlideIn(
                      index: i,
                      child: FormationCard(
                        formation: liste[i],
                        onTap: () => Navigator.of(context).push(
                          MaterialPageRoute(builder: (_) => FormationDetailScreen(formation: liste[i])),
                        ),
                      ),
                    ),
                  ),
          ),
        ],
      ),
    );
  }
}

class _FilterChip extends StatelessWidget {
  final String label;
  final bool selected;
  final VoidCallback onTap;

  const _FilterChip({required this.label, required this.selected, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(right: 8),
      child: ChoiceChip(
        label: Text(label),
        selected: selected,
        onSelected: (_) => onTap(),
      ),
    );
  }
}
